import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-highlight',
    templateUrl: './highlight.component.html',
    styleUrls  : ['./highlight.component.scss']
})
export class DocsComponentsHighlightComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
